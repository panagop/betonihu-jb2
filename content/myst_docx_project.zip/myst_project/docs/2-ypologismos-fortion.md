# 2 Υπολογισμός φορτίων

```{toctree}
:maxdepth: 1

2-1-fortia-plakon.md
2-2-fortia-dokon.md
2-3-seismos.md
```
