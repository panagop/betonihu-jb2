# 1 Δεδομένα

```{toctree}
:maxdepth: 1

1-1-geometria.md
```
