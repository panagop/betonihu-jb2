# 3 Εντατικά μεγέθη

Θεωρήθηκε ότι από την επίλυση με τον Η/Υ προέκυψαν τα εξής αποτελέσματα (χρησιμοποιήθηκαν αυθαίρετες τιμές που πλησιάζουν αυτές της επίλυσης, δεν έγινε όμως στην πραγματικότητα επίλυση για τα δεδομένα του παραδείγματος)

<table>
  <tr>
    <th>Αρ .<br>Μέλους</th>
    <th>Διατομή</th>
    <th>Ο.Κ.Α. χωρίς σεισμό:</th>
    <th>Ο.Κ.Α. χωρίς σεισμό:</th>
    <th>Ο.Κ.Α. χωρίς σεισμό:</th>
    <th>Ο.Κ.Α. με σεισμό:</th>
    <th>Ο.Κ.Α. με σεισμό:</th>
    <th>Ο.Κ.Α. με σεισμό:</th>
    <th>Ο.Κ.Α. με σεισμό:</th>
  </tr>
  <tr>
    <td>Αρ .<br>Μέλους</td>
    <td>Διατομή</td>
    <td>1.35G+1.5Q ( min / max )</td>
    <td>1.35G+1.5Q ( min / max )</td>
    <td>1.35G+1.5Q ( min / max )</td>
    <td>G+0.3Q±Ε ( min / max )</td>
    <td>G+0.3Q±Ε ( min / max )</td>
    <td>G+0.3Q±Ε ( min / max )</td>
    <td>G+0.3Q±Ε ( min / max )</td>
  </tr>
  <tr>
    <td>Αρ .<br>Μέλους</td>
    <td>Διατομή</td>
    <td>Ταυτόχρονη Ν</td>
    <td>Ακραία Μ y</td>
    <td>Ακραία V z</td>
    <td>Ταυτόχρονη<br>Ν</td>
    <td>Ακραία Μ y</td>
    <td>Ακραία V z</td>
  </tr>
  <tr>
    <td>1<br>(Ακραίος<br>στύλος)</td>
    <td>H=0<br>(A)</td>
    <td>-300.0</td>
    <td>110.0</td>
    <td>-80.0</td>
    <td>-230.0</td>
    <td>-60.0</td>
    <td>-100.0</td>
  </tr>
  <tr>
    <td>1<br>(Ακραίος<br>στύλος)</td>
    <td>H=0<br>(A)</td>
    <td>-450.0</td>
    <td>170.0</td>
    <td>-50.0</td>
    <td>-270.0</td>
    <td>250.0</td>
    <td>5.0</td>
  </tr>
  <tr>
    <td>1<br>(Ακραίος<br>στύλος)</td>
    <td>H= 6.5<br>(B 2 )</td>
    <td>-470.0</td>
    <td>-380.0</td>
    <td>-80.0</td>
    <td>-270.0</td>
    <td>-320.0</td>
    <td>-100.0</td>
  </tr>
  <tr>
    <td>1<br>(Ακραίος<br>στύλος)</td>
    <td>H= 6.5<br>(B 2 )</td>
    <td>-280.0</td>
    <td>-220.0</td>
    <td>-50.0</td>
    <td>-230.0</td>
    <td>-70.0</td>
    <td>5.0</td>
  </tr>
  <tr>
    <td>2<br>(Μεσαίος στύλος)</td>
    <td>H=0<br>(D)</td>
    <td>-1010.0</td>
    <td>-70.0</td>
    <td>-30.0</td>
    <td>-680.0</td>
    <td>-170.0</td>
    <td>-50.0</td>
  </tr>
  <tr>
    <td>2<br>(Μεσαίος στύλος)</td>
    <td>H=0<br>(D)</td>
    <td>-1010.0</td>
    <td>70.0</td>
    <td>30.0</td>
    <td>-678.0</td>
    <td>170.0</td>
    <td>50.0</td>
  </tr>
  <tr>
    <td>2<br>(Μεσαίος στύλος)</td>
    <td>H= 6.5<br>(C 2 )</td>
    <td>-1010.0</td>
    <td>-140.0</td>
    <td>-30.0</td>
    <td>-678.0</td>
    <td>-160.0</td>
    <td>-50.0</td>
  </tr>
  <tr>
    <td>2<br>(Μεσαίος στύλος)</td>
    <td>H= 6.5<br>(C 2 )</td>
    <td>-1010.0</td>
    <td>140.0</td>
    <td>30.0</td>
    <td>-680.0</td>
    <td>160.0</td>
    <td>50.0</td>
  </tr>
  <tr>
    <td>4<br>(Αριστερή Δοκός)</td>
    <td>0<br>(B 1 )</td>
    <td>&nbsp;</td>
    <td>-350.0</td>
    <td>280.0</td>
    <td>&nbsp;</td>
    <td>-320.0</td>
    <td>230.0</td>
  </tr>
  <tr>
    <td>4<br>(Αριστερή Δοκός)</td>
    <td>0<br>(B 1 )</td>
    <td>&nbsp;</td>
    <td>-200.0</td>
    <td>470.0</td>
    <td>&nbsp;</td>
    <td>-80.0</td>
    <td>270.0</td>
  </tr>
  <tr>
    <td>4<br>(Αριστερή Δοκός)</td>
    <td>1∙L 1 /4</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>4<br>(Αριστερή Δοκός)</td>
    <td>2∙L 1 /4</td>
    <td>&nbsp;</td>
    <td>310.0</td>
    <td>70.0</td>
    <td>&nbsp;</td>
    <td>300.0</td>
    <td>-52.0</td>
  </tr>
  <tr>
    <td>4<br>(Αριστερή Δοκός)</td>
    <td>2∙L 1 /4</td>
    <td>&nbsp;</td>
    <td>620.0</td>
    <td>-45.0</td>
    <td>&nbsp;</td>
    <td>340.0</td>
    <td>-18.0</td>
  </tr>
  <tr>
    <td>4<br>(Αριστερή Δοκός)</td>
    <td>3∙L 1 /4</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>4<br>(Αριστερή Δοκός)</td>
    <td>4∙L 1 /4<br>(C 1 )</td>
    <td>&nbsp;</td>
    <td>-1100.0</td>
    <td>-600.0</td>
    <td>&nbsp;</td>
    <td>-680.0</td>
    <td>-350.0</td>
  </tr>
  <tr>
    <td>4<br>(Αριστερή Δοκός)</td>
    <td>4∙L 1 /4<br>(C 1 )</td>
    <td>&nbsp;</td>
    <td>-700.0</td>
    <td>-400.0</td>
    <td>&nbsp;</td>
    <td>-520.0</td>
    <td>-310.0</td>
  </tr>
</table>
